package compito_20230222;

public class GestioneSimClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GestioneSim gSim = new GestioneSim();
		gSim.esegui();
	
	}

}
